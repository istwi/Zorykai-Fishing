# Reparo no fundo do Lago Florestal

A remoção da ruína submersa deixou uma depressão retangular perto de `X 2, Z 107`. O fundo foi recomposto entre `X 1–22` e `Z 101–116`, acompanhando a inclinação das bordas. O nível da água continua em `Y 63`.

O arquivo `Comparativo-leito-lago-florestal.png` mostra as alturas do fundo antes e depois. Em `evidencias-reparo-fabric.txt` estão os resultados da verificação em um servidor de teste com Minecraft 1.21.1, Fabric e Cobblemon 1.8.3.

## Atualização do mapa já instalado

Em relação ao ZIP anterior, o único arquivo do mundo alterado foi `pesca/region/r.0.0.mca`. Com o servidor parado e um backup salvo, substitua esse arquivo caso a região ainda esteja igual à versão anterior. Se houve construções ou outras edições desde a instalação, preserve o arquivo atual e aplique o reparo em uma cópia para evitar sobrescrever esse progresso.
