# Dimensão de pesca

O pacote contém o mundo Java Anvil `pesca/`, com DataVersion 3955, de Minecraft 1.21.1. A configuração original identifica a dimensão como `multiworld:pesca`. A edição usou uma cópia do ZIP recebido e se concentrou nos seis lagos indicados pelos prints.

## Alterações e demarcação

Os dois cantos são coordenadas inclusivas de referência no formato `X Y Z`. O tamanho é da caixa sugerida em X × Z. Lagos sinuosos e canais ligados podem pedir subdivisões se a ferramenta de regiões aceitar apenas cuboides. O ponto de pesca é a posição dos pés sobre o píer.

| Ordem e área | Tier | Cantos sugeridos | Tamanho | Píer |
|---|---:|---|---:|---|
| 1. Lago Florestal | 1 | `-66 40 52` e `85 81 157` | 152 × 106 | `1 65 60` |
| 2. Lago das Cerejeiras | 1 | `-205 40 -219` e `-18 81 -10` | 188 × 210 | `-145 65 -205` |
| 3. Lago Tropical | 2 | `87 40 91` e `244 81 230` | 158 × 140 | `123 65 185` |
| 4. Pântano Antigo | 2 | `-232 40 40` e `-61 81 227` | 172 × 188 | `-69 65 189` |
| 5. Lago Glacial | 3 | `96 70 -207` e `201 111 -82` | 106 × 126 | `132 95 -131` |
| 6. Caverna Cristalina | 4 | `-18 -7 -39` e `105 35 45` | 124 × 85 | `18 25 17` |

- **Florestal.** Retirada da ruína à vista e das duas estruturas submersas marcadas. Os trechos ocupados pelos blocos foram recompostos com água-fonte ou leito mineral apoiado no terreno. Píer de carvalho com iluminação lateral e transições rasas de andesito, argila e terra grossa. A coluna próxima de `16 63 103` tem água profunda e pode servir de referência para uma futura subárea.
- **Cerejeiras.** Píer de cerejeira com lanternas e detalhes rasos de calcita, arenito liso e terra enraizada. As ilhas e as cerejeiras continuam fazendo a orientação visual.
- **Tropical.** Píer de madeira da selva e bancos rasos com arenito e argila. As ilhas, os corais existentes e a navegação pelo centro foram preservados.
- **Pântano.** Píer de mangue, pequenos trechos com barro compactado, terra enraizada e musgo. A limpeza de vitórias-régias fica restrita ao corredor de arremesso.
- **Glacial.** Píer de pinheiro e abertura de pesca de 7 × 7 centrada em `140 93 -112`. A iluminação fica abaixo do volume onde a boia pousa, para ajudar a manter a abertura sem sacrificar a paisagem de gelo.
- **Cristalina.** Píer de carvalho escuro e detalhes de calcita, tufo e ametista nas partes rasas. As quedas d’água, as estalactites e a altura existente da caverna foram preservadas.

Os anéis ciano no comparativo indicam os píeres. O amarelo indica a abertura no gelo. As imagens são vistas renderizadas a partir dos blocos dos arquivos Anvil. O comparativo de estruturas mostra a projeção da alvenaria submersa.

## Compatibilidade e desempenho

Use Minecraft Java 1.21.1, Fabric e Cobblemon compatível com o servidor de origem. Consulte `blocos-de-mods.txt` para os IDs detectados nas paletas. O mundo contém biomas vanilla e blocos do Cobblemon. Os blocos de mods foram preservados. A edição usou blocos vanilla e nenhum NPC, entidade decorativa, circuito de redstone ou partícula permanente foi acrescentado.

No ZIP original há registros de itens caídos, blocos em queda, minecarts com baú e Pokémon. Eles foram preservados junto com as entidades e os arquivos auxiliares. Se houver picos no primeiro carregamento, esses blocos em queda e entidades são pontos a conferir. O jogo recalcula iluminação e mapas de altura nos chunks editados no primeiro carregamento.

Os tiers são a ordem de projeto da dimensão. Limites do mod, NPCs, barcos e tabelas de espécies precisam ser configurados separadamente, usando os pontos e cantos da tabela. Mantenha Wailord e Dondozo fora da Caverna Cristalina.

## Instalação

1. Extraia o ZIP em uma pasta de teste e confira os pontos da tabela. O mundo fica em `pesca/`, junto com o arquivo `multiworld-world.yml`. Evite a estrutura duplicada `pesca/pesca/`.
2. Para atualizar a dimensão existente, desligue o servidor e guarde uma cópia completa do `pesca/` atual. Confirme que a dimensão é `multiworld:pesca` e que a pasta tem o mesmo layout do backup.
3. Use o `pesca/` editado em uma cópia do servidor ou, se a dimensão atual **ainda corresponde ao ZIP enviado**, substitua somente os quatro arquivos em `pesca/region/` indicados abaixo. Isso preserva saves de outras dimensões e os outros arquivos do mundo.
4. Se o servidor recebeu construções novas dentro desses arquivos desde o envio, não sobrescreva as regiões atuais. Os arquivos Anvil contêm até 512 × 512 blocos em X/Z. Nesse caso, abra a cópia editada em teste e transfira as mudanças com seleção local, ou gere uma nova edição sobre um backup atual.

Os arquivos editados são `r.-1.-1.mca`, `r.-1.0.mca`, `r.0.-1.mca` e `r.0.0.mca`. O pacote é um mundo, por isso não requer o comando de colar schematic.
